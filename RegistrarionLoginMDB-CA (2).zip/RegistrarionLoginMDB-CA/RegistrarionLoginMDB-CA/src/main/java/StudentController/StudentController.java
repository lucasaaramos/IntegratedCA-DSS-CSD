package StudentController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import StudentEntity.Student;
import StudentService.StudentService;

@RestController
@RequestMapping("/students")
public class StudentController {
	@Autowired
	private StudentService studentService;

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Student addStudent(@RequestBody Student student) {
		return studentService.save(student);
	}
	
	@GetMapping(path="/{id}")
	public Student getStudent(@PathVariable int id) {
		return studentService.getStudent(id);
	}
	
	@GetMapping(path="/student/{student}")
	public <List>Student findNameStudent(@PathVariable String name) {
		return studentService.getName(name);			
	}
	
	@GetMapping(path="/email/{email}")
	public <List>Student findEmailStudent(@PathVariable String email) {
		return studentService.getEmail(email);			
	}
	
	@PutMapping
	public Student updateStudent(@RequestBody Student student) {
		return studentService.updateName(student); 
	}
	
	@DeleteMapping(path="/{id}")
	public String deleteStudent(@PathVariable int id ) {
		return studentService.delete(id);
	}
	
	public StudentService getStudentService() {
		return studentService;
	}

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}
	
	
}
