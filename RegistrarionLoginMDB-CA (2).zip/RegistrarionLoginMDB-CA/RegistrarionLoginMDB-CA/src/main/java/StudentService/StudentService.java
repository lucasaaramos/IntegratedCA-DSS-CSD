package StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import StudentEntity.Student;
import StudentRepository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;

	public Student save(Student stu) {
		return studentRepository.save(stu);
	}
	
	public Student getStudent(int id) {
		return studentRepository.findById(id).get();
			}
	
	public <List>Student updateName(Student student) {
		return studentRepository.findByName(student);				
	}
	
	public <List>Student updateEmail(Student student) {
		return studentRepository.findByEmail(student);				
	}
	
	public String delete(int id) {
		studentRepository.deleteById(id);
		return "Entity Deleted" + id;
	}
	
	public StudentRepository getStudentRepository() {
		return studentRepository;
	}

	public void setStudentRepository(StudentRepository studentRepository) {
		this.studentRepository = studentRepository;
	}

	public Student getName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Student getEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}


	
}
