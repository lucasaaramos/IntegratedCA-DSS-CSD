package SecurityConfiguration;

public class SecurityConfig {

}
