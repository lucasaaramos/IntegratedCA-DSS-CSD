package UserRepository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;


import UserEntity.User;


public interface UserRepository extends MongoRepository<User, Integer>{

	List<User> findByName(String name);

	User findByUserName(User user);

	User findByPassword(User user);


	
}
