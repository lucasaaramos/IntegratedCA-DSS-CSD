package UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import UserEntity.User;
import UserRepository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public User save(User stu) {
		return userRepository.save(stu);
	}
	
	public User getUser(int id) {
		return userRepository.findById(id).get();
			}
	
	public <List>User updateUserName(User user) {
		return userRepository.findByUserName(user);				
	}
	
	public <List>User updatePassword(User user) {
		return userRepository.findByPassword(user);				
	}
	
	public String delete(int id) {
		userRepository.deleteById(id);
		return "Entity Deleted" + id;
	}
	
	public UserRepository getUserRepository() {
		return userRepository;
	}

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	public User getUserName(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	public User getPassword(String password) {
		// TODO Auto-generated method stub
		return null;
	}


	
}
